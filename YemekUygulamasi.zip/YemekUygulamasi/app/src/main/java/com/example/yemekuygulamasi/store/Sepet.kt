package com.example.yemekuygulamasi.store

import com.example.yemekuygulamasi.data.endity.SepetYemekler
import com.example.yemekuygulamasi.data.endity.Yemekler

object Sepet {object Sepet { // sepet verisini tutar
    private val list = mutableListOf<SepetYemekler>()


    fun yemekEkle(yemek: Yemekler) {
        var eklendi = false
        for (y in list) { // bak bakalım daha önce eklendi mi
            if (y.sepet_yemek_id == yemek.yemek_id) { // daha önce eklenmiş
                eklendi = true
                break
            }
        }

        if (eklendi) { // eklendiyse, adetini arttır
            for (y in list) { // yemeği bul
                if (y.sepet_yemek_id == yemek.yemek_id) { // yemek bulundu
                    y.yemek_siparis_adet++
                    break
                }
            }
        } else { // eklenmediyse yeniden ekle
            val sepetYemek = SepetYemekler.from(yemek)
            sepetYemek.yemek_siparis_adet = 1
            list.add(sepetYemek)
        }

    }

    fun yemekSil(yemek: Yemekler) {
        for (y in list) { // yemeği bul
            if (y.sepet_yemek_id == yemek.yemek_id) { // yemek bulundu
                if (y.yemek_siparis_adet == 1) {
                    list.remove(y)
                } else {
                    y.yemek_siparis_adet--
                }
                break
            }
        }
    }

}
}