package com.example.yemekuygulamasi.data.endity

class YemeklerCRUDCevap(var success:String,var message:String) {
}