package com.example.yemekuygulamasi.data.endity

class SepetYemeklerCevap(var sepet_yemekler:List<SepetYemekler>, var success:String) {
}