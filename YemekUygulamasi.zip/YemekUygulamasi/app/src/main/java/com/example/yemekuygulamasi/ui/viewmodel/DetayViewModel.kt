package com.example.yemekuygulamasi.ui.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.yemekuygulamasi.data.endity.SepetYemekler
import com.example.yemekuygulamasi.data.endity.Yemekler
import com.example.yemekuygulamasi.data.endity.YemeklerCRUDCevap
import com.example.yemekuygulamasi.data.repo.YemeklerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DetayViewModel @Inject constructor(var yemeklerRepository: YemeklerRepository) : ViewModel() {
//    var yemeklerCRUDCevap =
    val yemek = MutableLiveData<SepetYemekler>()
    val sepeteEkleResponse = MutableLiveData<String>()

    fun adetAzalt() {
        if (yemek.value?.yemek_siparis_adet != 0) {
            yemek.value?.let {
                it.yemek_siparis_adet--
                yemek.value = yemek.value

            }
        }
    }

    fun adetArttir() {
        yemek.value?.let {
            it.yemek_siparis_adet++
            yemek.value = yemek.value
        }
    }

    fun setData(yemek: Yemekler) {
        this.yemek.value = SepetYemekler.from(yemek)
    }

    fun sepeteEkle() {
        // yemek.value objesini YemeklerApi altındaki sepeteYemekEkle fonksiyonu ile sunucuya/servise gönder
        // sepeteEkleResponse.value = sepetRepo.sepeteYemekEkle()
            CoroutineScope(Dispatchers.Main).launch {
                yemek.value?.let {y ->
                    sepeteEkleResponse.value =
                        yemeklerRepository.sepeteYemekleriEkle(
                            y.sepet_yemek_id,
                            y.yemek_adi, y.yemek_resim_adi,
                            y.yemek_fiyat, y.yemek_siparis_adet, y.kullanici_adi)
                }

            }
    }
}