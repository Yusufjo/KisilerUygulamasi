package com.example.kisileruygulamasi.data.endity

import java.io.Serializable

data class Kisiler(val kisi_id:Int, val kisi_ad:String, val kisi_tel:String) :Serializable{

}